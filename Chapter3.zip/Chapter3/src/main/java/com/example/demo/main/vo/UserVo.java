package com.example.demo.main.vo;

import lombok.Data;

@Data
public class UserVo {

	private long id;
	private String userName;
	private int sexCode;
	private String sexName;
	private String note;
}
