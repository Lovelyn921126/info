package com.example.demo.main.service;


import org.springframework.stereotype.Service;

import com.example.demo.main.bean.User;

@Service
public class UserService {
  
	public static void printUser(User user) {
		System.out.println("编号："+user.getId());
		System.out.println("姓名："+user.getUserName());
		System.out.println("备注"+user.getNote());
	}
}
