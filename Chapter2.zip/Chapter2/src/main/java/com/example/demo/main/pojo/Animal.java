package com.example.demo.main.pojo;

public interface Animal {
  public void use();
}
