package com.example.demo.main.intercept;

public interface HellowService {
  
	public void sayHellow(String name);
}
