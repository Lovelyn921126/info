package com.example.demo.main.mybatis;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.mapper.MapperFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

public class Factory {
  
/*	@Autowired
	private SqlSessionFactory sessionFactory;
	
	@Bean
	public MapperFactoryBean<?> init() {
		MapperFactoryBean<?> bean=new MapperFactoryBean<>();
	}*/
}
