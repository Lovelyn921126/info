package com.example.demo.main.aop;

import com.example.demo.main.bean.User;

public interface UserValidate {
  
	public boolean validate(User user) ;
}
