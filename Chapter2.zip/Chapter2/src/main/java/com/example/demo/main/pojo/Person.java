package com.example.demo.main.pojo;

public interface Person {
 
	public void service();
	public void setAnamail(Animal animal);
}
