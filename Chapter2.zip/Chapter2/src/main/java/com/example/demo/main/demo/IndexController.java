package com.example.demo.main.demo;

import org.omg.CORBA.PRIVATE_MEMBER;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.main.aop.UserService;
import com.example.demo.main.aop.UserValidate;
import com.example.demo.main.bean.User;
import com.example.demo.main.intercept.HellowService;

@Controller
public class IndexController {
	
	@Autowired
	@Qualifier("myHellowServiceImpl")
	private HellowService hellowService;
	
	@Autowired
	private UserService userService;
    
	@RequestMapping("/index")
	public String index() {
		User user=new User();
	//UserValidate userValidate=	(UserValidate) hellowService;
	//if (userValidate.validate(user)) {
		hellowService.sayHellow("lyn");
	//}
		
		return "index";
	}
	
	@RequestMapping("/user")
	public String user(Integer id,String note,String userName) {
		User user=new User();
		user.setId(id);
		user.setNote(note);
		user.setUserName(userName);
	//UserValidate userValidate=	(UserValidate) userService;
	//if (userValidate.validate(user)) {
		userService.printUser(user);
	//}
		
		return "index";
	}
}
