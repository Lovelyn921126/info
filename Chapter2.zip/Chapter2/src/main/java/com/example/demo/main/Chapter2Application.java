package com.example.demo.main;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.PropertySource;

import com.example.demo.main.aop.MyAspect;
import com.example.demo.main.aop.MyAspect2;
import com.example.demo.main.aop.MyAspect3;

@SpringBootApplication(scanBasePackages=("com.example.demo.main.*"))
@PropertySource(value= {"classpath:jdbc.properties"},ignoreResourceNotFound=true)
@MapperScan(basePackages="com.example.demo.main.*")
public class Chapter2Application {
    
	@Bean(name="myAspect")
	public MyAspect initAspect() {
		return new MyAspect();
	}
	@Bean(name="myAspect2")
	public MyAspect2 initAspect2() {
		return new MyAspect2();
	}
	@Bean(name="myAspect3")
	public MyAspect3 initAspect3() {
		return new MyAspect3();
	}
	public static void main(String[] args) {
		SpringApplication.run(Chapter2Application.class, args);
	}
}
