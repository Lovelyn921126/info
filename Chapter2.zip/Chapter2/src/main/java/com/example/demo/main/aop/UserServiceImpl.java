package com.example.demo.main.aop;

import org.springframework.stereotype.Service;

import com.example.demo.main.bean.User;

@Service
public class UserServiceImpl implements UserService {

	@Override
	public void printUser(User user) {
		if (user==null) {
			throw new RuntimeException("参数为空");
		}
		System.out.println("id::"+user.getId());
		System.out.println("note::"+user.getNote());
		System.out.println("userName::"+user.getUserName());
		
	}

}
