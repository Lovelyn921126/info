package com.example.demo.main.aop;

import org.springframework.stereotype.Service;

import com.example.demo.main.bean.User;

@Service
public interface UserService {
  
	public void printUser(User user);
}
